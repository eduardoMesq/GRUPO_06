package com.example.movieapp;

import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.movieapp.adapter.MovieAdapter;
import com.example.movieapp.model.Movie;
import com.example.movieapp.model.MovieResponse;
import com.example.movieapp.network.ApiService;
import com.example.movieapp.network.RetrofitClient;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {
    private RecyclerView rvMovies;
    private MovieAdapter adapter;
    private String apiKey;
    private String imageBaseUrl;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rvMovies = findViewById(R.id.rvMovies);
        rvMovies.setLayoutManager(new LinearLayoutManager(this));

        apiKey = getString(R.string.tmdb_api_key);
        imageBaseUrl = getString(R.string.image_base_url);

        if (apiKey == null || apiKey.isEmpty() || apiKey.contains("YOUR_TMDB_API_KEY")) {
            Toast.makeText(this, "⚠️ Insere a tua TMDB API key em res/values/strings.xml", Toast.LENGTH_LONG).show();
            return;
        }

        fetchPopularMovies();
    }

    private void fetchPopularMovies() {
        ApiService apiService = RetrofitClient.getClient().create(ApiService.class);
        Call<MovieResponse> call = apiService.getPopularMovies(apiKey, 1);
        call.enqueue(new Callback<MovieResponse>() {
            @Override
            public void onResponse(Call<MovieResponse> call, Response<MovieResponse> response) {
                if (response.isSuccessful() && response.body() != null) {
                    List<Movie> movies = response.body().getResults();
                    adapter = new MovieAdapter(MainActivity.this, movies, imageBaseUrl);
                    rvMovies.setAdapter(adapter);
                } else {
                    Toast.makeText(MainActivity.this, "Erro ao obter filmes", Toast.LENGTH_LONG).show();
                    Log.e("MainActivity", "Response error: " + response.message());
                }
            }

            @Override
            public void onFailure(Call<MovieResponse> call, Throwable t) {
                Toast.makeText(MainActivity.this, "Falha: " + t.getMessage(), Toast.LENGTH_LONG).show();
                Log.e("MainActivity", "Failure: ", t);
            }
        });
    }
}
