package com.example.movieapp.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.movieapp.MovieDetailActivity;
import com.example.movieapp.R;
import com.example.movieapp.model.Movie;

import java.util.List;

public class MovieAdapter extends RecyclerView.Adapter<MovieAdapter.MovieViewHolder> {
    private final Context ctx;
    private final List<Movie> movies;
    private final String imageBaseUrl;

    public MovieAdapter(Context ctx, List<Movie> movies, String imageBaseUrl) {
        this.ctx = ctx;
        this.movies = movies;
        this.imageBaseUrl = imageBaseUrl;
    }

    @NonNull
    @Override
    public MovieViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(ctx).inflate(R.layout.item_movie, parent, false);
        return new MovieViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MovieViewHolder holder, int position) {
        Movie m = movies.get(position);

        // Defensive checks
        String title = m.getTitle() != null ? m.getTitle() : "Sem título";
        String overview = m.getOverview() != null ? m.getOverview() : "";
        String posterPath = m.getPosterPath();

        holder.textViewTitle.setText(title);
        holder.textViewOverview.setText(overview);

        String posterUrl = "https://image.tmdb.org/t/p/w500" + m.getPosterPath();
        Glide.with(ctx)
                .load(posterUrl)
                .centerCrop()
                .placeholder(android.R.drawable.ic_menu_report_image)
                .into(holder.imageViewPoster);

        holder.itemView.setOnClickListener(v -> {
            Intent i = new Intent(ctx, MovieDetailActivity.class);
            i.putExtra("title", m.getTitle());
            i.putExtra("overview", m.getOverview());
            i.putExtra("poster_path", m.getPosterPath());
            i.putExtra("rating", m.getVoteAverage());
            ctx.startActivity(i);
        });
    }

    @Override
    public int getItemCount() {
        return movies != null ? movies.size() : 0;
    }

    static class MovieViewHolder extends RecyclerView.ViewHolder {
        ImageView imageViewPoster;
        TextView textViewTitle;
        TextView textViewOverview;

        MovieViewHolder(@NonNull View itemView) {
            super(itemView);
            imageViewPoster = itemView.findViewById(R.id.imageViewPoster);
            textViewTitle = itemView.findViewById(R.id.textViewTitle);
            textViewOverview = itemView.findViewById(R.id.textViewOverview);
        }
    }
}
