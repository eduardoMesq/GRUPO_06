package com.example.movieapp.model;

import com.google.gson.annotations.SerializedName;

public class Movie {
    private int id;
    private String title;

    @SerializedName("poster_path")
    private String posterPath;

    @SerializedName("overview")
    private String overview;

    @SerializedName("vote_average")
    private float voteAverage;

    public int getId() { return id; }
    public String getTitle() { return title; }
    public String getPosterPath() { return posterPath; }
    public String getOverview() { return overview; }
    public float getVoteAverage() { return voteAverage; }
}
