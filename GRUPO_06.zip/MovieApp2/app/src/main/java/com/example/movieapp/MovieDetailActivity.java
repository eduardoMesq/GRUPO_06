package com.example.movieapp;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;

public class MovieDetailActivity extends AppCompatActivity {
    private ImageView imgPoster;
    private TextView tvTitle, tvOverview, tvRating;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_movie_detail);

        imgPoster = findViewById(R.id.imgPosterDetail);
        tvTitle = findViewById(R.id.tvTitleDetail);
        tvOverview = findViewById(R.id.tvOverviewDetail);
        tvRating = findViewById(R.id.tvRating);

        // Primeiro obtém os dados do Intent
        String title = getIntent().getStringExtra("title");
        String overview = getIntent().getStringExtra("overview");
        String posterPath = getIntent().getStringExtra("poster_path");
        float rating = getIntent().getFloatExtra("rating", 0f);

        // Depois cria o URL completo da imagem
        String imageBaseUrl = getString(R.string.image_base_url) + posterPath;

        // Preenche os campos
        tvTitle.setText(title);
        tvOverview.setText(overview);
        tvRating.setText("⭐ Rating: " + rating);

        // Carrega a imagem com Glide
        Glide.with(this)
                .load(imageBaseUrl)
                .centerCrop()
                .placeholder(android.R.drawable.ic_menu_report_image)
                .into(imgPoster);
    }
}
